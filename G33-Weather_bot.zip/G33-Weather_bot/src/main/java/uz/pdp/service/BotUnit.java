package uz.pdp.service;

public class BotUnit {
    public static String BOT_NAME ="t.me/dragon_07bot";
    public static String BOT_TOKEN ="6933429485:AAF3jZSZJ3AcDK-f3F5hvwmtjALP-oMkGKc";
}
