package uz.pdp.resoursec.weather;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class MainData {
    private double temp;
    private double humidity;
}
