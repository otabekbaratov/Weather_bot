package uz.pdp.resoursec.weather;

import lombok.Getter;
import lombok.Setter;

@Getter
@Setter
public class WeatherData {
    private MainData main;
    @Getter
    private int cod;

}
